## Implementing factorial of n with recursion and stack
## n! = n * (n-1) * (n-2) * ... * 1
## 0! = 1

def factorial_recur(n):
    if n==0:
        return 1
    else:
        return n * factorial_recur(n-1)

def factorial_stack(n):
    s = []
    fac = 1
    while True:
        if n==0:
            while s:
                fac = fac * s.pop()
            break
        else:
            s.append(n)
            n = n-1
    return fac

if __name__ == '__main__':
    print('10! using recursion: ', factorial_recur(10))
    print('10! using stack: ', factorial_stack(10))
