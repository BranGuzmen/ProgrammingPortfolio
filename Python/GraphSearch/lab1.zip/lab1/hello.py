print('Welcome to CSI-535/435')
